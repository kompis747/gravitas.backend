# Suit Store — Setup & Deployment Guide

This project has two parts:
- **medusa-backend/** — the store engine: products, inventory, orders, and the admin panel (built into Medusa)
- **storefront/** — the customer-facing website (Next.js), talks to the backend via its API

Your GoDaddy domain stays as your domain registrar the whole time — you're just pointing its DNS at wherever the backend/storefront actually run (not at GoDaddy's own hosting, since Website Builder can't run this).

---

## 1. Local development (do this first, on your own machine)

You'll need Node.js (v16+) and Docker installed locally.

### Backend
```bash
cd medusa-backend
cp .env.example .env          # fill in real secrets (see notes below)
docker compose up -d          # starts Postgres + Redis
npm install                   # requires internet access
npx medusa migrations run     # sets up the database tables
npm run seed                  # loads starter categories + example product
npm run dev                   # starts Medusa at http://localhost:9000
```

Admin panel will be available at `http://localhost:7001` once running —
create your first admin user with:
```bash
npx medusa user -e you@youremail.com -p yourpassword
```

### Storefront
```bash
cd storefront
cp .env.example .env.local
npm install
npm run dev                   # starts at http://localhost:8000
```

At this point you can browse the store and manage products locally.

---

## 2. Filling in secrets (.env values)

- `JWT_SECRET` / `COOKIE_SECRET`: generate random strings (e.g. `openssl rand -hex 32`)
- `STRIPE_API_KEY` / `STRIPE_WEBHOOK_SECRET`: from your Stripe dashboard → Developers → API keys / Webhooks
- `DATABASE_URL` / `REDIS_URL`: provided by your hosting service once deployed (see step 3)

---

## 3. Hosting (where this actually runs live)

Medusa needs a real server (not static hosting). Two straightforward options:

### Option A — Railway (easiest)
1. Create a Railway account, new project
2. Add a PostgreSQL and Redis service (one click each)
3. Deploy `medusa-backend/` as a service, connect the Postgres/Redis URLs into its env vars
4. Deploy `storefront/` as a separate service, point `NEXT_PUBLIC_MEDUSA_BACKEND_URL` at the backend's Railway URL

### Option B — Render
Same idea as Railway: a Postgres instance, a Redis instance, a web service for the backend, a web service for the storefront.

Both give you a URL like `your-app.up.railway.app` — you'll point your domain at this next.

---

## 4. Pointing your GoDaddy domain

Once deployed on Railway/Render, they'll give you a target (a CNAME or IP to point to).

In GoDaddy:
1. Go to **My Products → DNS** for your domain
2. Add/update records:
   - `yourdomain.com` → CNAME/A record pointing to your storefront's hosting
   - `admin.yourdomain.com` → CNAME pointing to your Medusa backend (so the admin panel has its own address)
3. DNS changes can take a few hours to propagate

Your GoDaddy Website Builder plan is not used at all in this setup — the domain registration is the only piece of GoDaddy you're keeping.

---

## 5. Before going live (checklist)

- [ ] Replace `example_product` in `data/seed.json` with real products once your supplier order and photos are ready
- [ ] Confirm Stripe account is in live mode (not test mode) with real API keys
- [ ] Set real inventory quantities once stock arrives
- [ ] Test a full checkout end-to-end with a real card (small amount) before announcing launch
- [ ] Set up the shipping method/rates in the admin panel (Settings → Shipping)

---

## Notes
- This was scaffolded without live internet access, so `npm install` steps must be run on your own machine or directly on the hosting service — that's normal and expected.
- Medusa's own docs (docs.medusajs.com) are the best source if a specific step behaves differently than expected — versions update frequently.
